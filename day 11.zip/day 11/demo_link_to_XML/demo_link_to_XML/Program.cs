﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace demo_link_to_XML
{
    class Program
    {
        string path = "C:\\dot net taining\\day 11\\demo_link_to_XML\\ParticipantsDetails.xml";

        public void GETXMLData()
        {
            Console.WriteLine("link to XML");
            // step1: Connection string
            // private string path = "ParticipantsDetails.xml";
            // Step 1: Connection String
            // string path = "C:\\dot net taining\\day 11\\demo_link_to_XML\\ParticipantsDetails.xml";

            XDocument doc = XDocument.Load(path);

            var part = from Participant in doc.Descendants("Participant")
                       select new
                       {
                           ID = Convert.ToInt32(Participant.Attribute("ID").Value),
                           Name = Participant.Element("Name").Value
                       };
            foreach (var item in part)
            {
                Console.WriteLine(item.ID + " " + item.Name);
                // Console.WriteLine("Hello");
            }

        }
        private void InsertXMLData(string name)
        {
            //  try
            //  {
            XDocument myXML = XDocument.Load(path);
            XElement newParticipant = new XElement("Participant", new XElement("Name", name));
            var LastUser = myXML.Descendants("Participant").Last();
            int newID = Convert.ToInt32(LastUser.Attribute("ID").Value);

            newParticipant.SetAttributeValue("ID", newID + 1); // Setting Attribute
            myXML.Element("Partcipants").Add(newParticipant); // Adding new Element
            myXML.Save(path);
            // }
            //  catch (Exception)
            //  {

            // }


        }

        private void ModifyXMLData(string name, int Id , int newID)

        {
            XDocument myXML = XDocument.Load(path);
            var Students = from Student in myXML.Descendants("Participant")
                           where Student.Attribute("ID").Value == Id.ToString() select Student;

            foreach (var item in Students)
            {
                item.Attribute("ID").SetValue(newID);
                item.Element("Name").SetValue(name);
            }

            myXML.Save(path);


        }

        private void DeleteXMLData( int Id)

        {
            XDocument myXML = XDocument.Load(path);
            var Students = from Student in myXML.Descendants("Participant")
                           where Student.Attribute("ID").Value == Id.ToString()
                           select Student;

            Students.Remove();
            myXML.Save(path);


        }
        static void Main(string[] args)
        {
            // Step 1: Connection String
            
            Program obj1 = new Program();
            //obj1.GETXMLData();

            //obj1.InsertXMLData("Hussey");
            // obj1.GETXMLData();
           // obj1.InsertXMLData("Andrew");

           // obj1.GETXMLData();
            Console.WriteLine("adding new element");

           // obj1.InsertXMLData("suman");
            obj1.GETXMLData();
            Console.WriteLine("after modifying data");
            //obj1.ModifyXMLData("trisha_deepak kumar_intersoft", 4, 5);
            obj1.GETXMLData();
            Console.WriteLine("after delete");
            obj1.DeleteXMLData(2);
            obj1.GETXMLData();




        }

    }

}

