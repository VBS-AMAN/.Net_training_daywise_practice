﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment_question_2
{
    class Program
    {
        static void Main(string[] args)
        {





            // /assignment_question_2
            /* int[] marks = new int[5] { 99, 98, 92, 97, 95 };
              for (int i = 0; i < marks.Length; i++)
              {
                  Console.WriteLine(marks[i]);
              }
            Console.WriteLine("delete");
            var a = marks.Take(marks.Length - 2).ToArray();
            foreach (var item in a)
            {
                Console.WriteLine(item);
            }
              Console.WriteLine("Max: " + marks.Max());
              Console.WriteLine("Min: " + marks.Min());
              Console.WriteLine("Sum: " + marks.Sum());
              Array.Sort(marks);
              Console.WriteLine("Sorted Array: ");
              foreach (var item in marks)
              {
                  Console.WriteLine(item);
              }*/






            // assignment question 3
            /* Console.WriteLine("-------collection--list(generic)--------");
              Console.WriteLine("-------implementing generic list collection--------");
              //step1"creating a list
              //step2: "adding element to collection
              //step3: displaying element of collection

              var movies = new List<string>();
              movies.Add("end game");
              movies.Add("bhul bhulaiya");
              movies.Add("ram leela");
              movies.Add("OMG");
              movies.Add("INCEPTION");


              Console.WriteLine(movies.Capacity);
              Console.WriteLine(movies.Count);
              Console.WriteLine(movies);

              foreach (var item in movies)

              {
                  Console.WriteLine(item);
              }

              movies[0] = "infinity war";
              foreach (var item in movies)
              {
                  Console.WriteLine(item);
              }

              Console.WriteLine(movies.Contains("infinity war"));
              Console.WriteLine("-------after removing ram leela -----------");
              //  movies.Remove("ram leela");
              movies.RemoveAt(1);
              foreach (var item in movies)
              {
                  Console.WriteLine(item);

              }
            */

            /* Console.WriteLine("----------array list imp - non generic collection-----");

             ArrayList myfav = new ArrayList();
             myfav.Add("dell - latitude"); //string
             myfav.Add(true); //bool
             myfav.Add('p');   //char
             myfav.Add(22); //int
             myfav.Add(2.14); //double value
             myfav.Add(25.22D); //float

             Console.WriteLine(myfav.Capacity);
             Console.WriteLine(myfav.Count);


             foreach (var item in myfav) 
             {
                 Console.WriteLine(item);

             }*/

            // assignment question 3

            /*Stack<int> my_stack = new Stack<int>();
            my_stack.Push(10);
            my_stack.Push(20);
            my_stack.Push(30);
            Console.WriteLine("count:"+my_stack.Count());
            Console.WriteLine("current:" + my_stack.Peek());

            my_stack.Pop();
            Console.WriteLine("current:" + my_stack.Peek());
            Console.WriteLine("count:" + my_stack.Count());

 // Create a stack
            // Using Stack class
            /* Stack my_stack = new Stack();

             // Adding elements in the Stack
             // Using Push method
             my_stack.Push("Geeks");
             my_stack.Push("geeksforgeeks");
             my_stack.Push('G');
             my_stack.Push(null);
             my_stack.Push(1234);
             my_stack.Push(490.98);

             // Accessing the elements
             // of my_stack Stack
             // Using foreach loop
             foreach (var elem in my_stack)
             {
                 Console.WriteLine(elem);

             }
             Console.WriteLine("Total elements present in" +
                    " my_stack: {0}", my_stack.Count);

           ///  my_stack.Pop();

             // After Pop method
           //  Console.WriteLine("Total elements present in " +
                        //   "my_stack: {0}", my_stack.Count);


             // Remove all the elements
             // from the stack
             my_stack.Clear();

             // After Pop method
             Console.WriteLine("Total elements present in " +
                           "my_stack: {0}", my_stack.Count);
            // Checking if the element is
            // present in the Stack or not
            if (my_stack.Contains("geeksforgeeks") == true)
            {
                Console.WriteLine("Element is found...!!");
            }

            else
            {
                Console.WriteLine("Element is not found...!!");
                //    }

            } */

            /* Queue<string> country = new Queue<string>();
             country.Enqueue("USA");
             country.Enqueue("INDIA");
             country.Enqueue("London");
             country.Enqueue("IZRAIEL");
             country.Enqueue("JAPAN");
             country.Enqueue("MARS");
             foreach(var item in country)
             {
                 Console.WriteLine(item);
             }
             Console.WriteLine("country.Dequeue: " + country.Dequeue());
              Console.WriteLine("country.Peek: " + country.Peek());
              Console.WriteLine("Count: " + country.Count);*/

            /* Queue q = new Queue();
             q.Enqueue("Hello.. !");
             q.Enqueue(0.0123);
             q.Enqueue(1);
            q.Enqueue("to the");
             q.Enqueue(2);
             q.Enqueue("to the");
             q.Enqueue(3);
             foreach (var item in q)
             {
                 Console.WriteLine(item);
             }

             Console.WriteLine("Count: " + q.Count);
             Console.WriteLine("Dequeue: " + q.Dequeue());
             Console.WriteLine("Peek: " + q.Peek());
             Console.WriteLine("Count: " + q.Count);*/

            /*  Hashtable h = new Hashtable();
              h.Add(1, "abc");
              h.Add(2, "aaa");
              h.Add(3, "aaaa");
              h.Add(4, "aaaaa");
              foreach(DictionaryEntry item in h)
              {
                  Console.WriteLine($"key: {item.Key}, value: {item.Value}");

              }
              Console.WriteLine(h.Contains(4));
              Console.WriteLine(h.ContainsValue("abc"));*/

            // question 4
            /* Dictionary<string, Int16> Authors = new Dictionary<string, Int16>();
             Authors.Add("aman", 40);
             Authors.Add("rahul", 30);
             Authors.Add("govind", 60);
             Authors.Add("raksham", 50);
             foreach(KeyValuePair<string, Int16> item in Authors)
             {
                 Console.WriteLine($"Author Name : {item.Key}   and No. of publications : {item.Value}");
             }
             Authors.Remove("rahul");
             Console.WriteLine("After Removal");
             foreach (KeyValuePair<string, Int16> item in Authors)
             {
                 Console.WriteLine($"Author Name : {item.Key}   and No. of publications : {item.Value}");
             }
             Console.WriteLine(Authors.ContainsKey("govind"));
             Console.WriteLine(Authors.ContainsValue(20));*/

           /* Dictionary<string, float> PriceList = new Dictionary<string, float>(3);
            PriceList.Add("Tea", 3.25f);
            PriceList.Add("Juice", 2.76f);
            PriceList.Add("Milk", 1.15f);
            foreach (KeyValuePair<string, float> item in PriceList)
            {
                Console.WriteLine($"item Name : {item.Key}   and weight of item : {item.Value}");
            }
            PriceList.Remove("Tea");
            Console.WriteLine("After Removal");
            foreach (KeyValuePair<string, float> item in PriceList)
            {
                Console.WriteLine($"item Name : {item.Key}   and weight of item : {item.Value}");
            }
            Console.WriteLine(PriceList.ContainsKey("Milk"));
            Console.WriteLine(PriceList.ContainsValue(1.15f)); */



        }




    }
}