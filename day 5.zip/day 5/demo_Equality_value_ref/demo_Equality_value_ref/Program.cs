﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_Equality_value_ref
{
    class Program
    {
        public struct MyStruct // create own structure
        {
            public int ID { get; set; }
            public string name { get; set; }

        };
        static void Main(string[] args)
        {
            Console.WriteLine("implementing equality in c#");
            Member Obj1 = new Member { ID = 1, Name = "aman", Address = "jaipur" };
            Member Obj2 = new Member { ID = 2, Name = "deepak", Address = "delhi" };
            //create new obj for true...?
            Member Obj3 = Obj1; // here we have two ref for same memory location
            //check wether they are same....values 
            Console.WriteLine("lets check if two objects have same aur unique value:\n");
            Console.WriteLine(Obj1 == Obj2); // if both object point to the same location
            Console.WriteLine(Obj1.Equals(Obj2)); //in this conditionalso false
            Console.WriteLine(System.Object.ReferenceEquals(Obj1,Obj2)); // if object instance are same instance or not
                                                                         // in 3rd condition also false

            Console.WriteLine("lets check if two objects have same aur unique value:\n");
            Console.WriteLine(Obj1 == Obj3);
            Console.WriteLine(Obj1.Equals(Obj3)); //in this conditionalso false
            Console.WriteLine(System.Object.ReferenceEquals(Obj1, Obj3));

            //-----------
            Console.WriteLine(":\n");
            Console.WriteLine(Obj1 == Obj3);
            Console.WriteLine(Obj1.Equals(Obj3)); //in this conditionalso false
            Console.WriteLine(System.Object.ReferenceEquals(Obj1, Obj3));

            // for true (when 


            Obj1 = Obj2;
            Console.WriteLine("lets check if two objects have same aur unique value:\n");
            Console.WriteLine(Obj1 == Obj2); // if both object point to the same location
            Console.WriteLine(Obj1.Equals(Obj2)); //in this conditionalso false
            Console.WriteLine(System.Object.ReferenceEquals(Obj1, Obj2));

            /// for structure part

            Console.WriteLine("implementing value type equality using structure");

            MyStruct myStruct1 = new MyStruct { ID = 1, name = "Aman" };
            MyStruct myStruct2 = new MyStruct { ID = 1, name = "Aman" };
            //Console.WriteLine(myStruct1 == myStruct2); // compile time error
            Console.WriteLine(System.Object.ReferenceEquals(myStruct1, myStruct2));
            //false because different memory location
            Console.WriteLine(myStruct1.Equals(myStruct2)); //checking for value
            //when we write same name and id




        }
    }
}
