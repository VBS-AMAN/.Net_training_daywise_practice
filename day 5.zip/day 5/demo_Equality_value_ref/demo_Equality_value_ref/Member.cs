﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_Equality_value_ref
{
    class Member
    {
        // creating properties
        public string Name { get; set; }
        public string Address { get; set; }
        public int ID { get; set; }

    }
}
