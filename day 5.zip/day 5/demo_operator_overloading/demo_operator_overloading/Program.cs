﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_operator_overloading
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("operator overloading");
            Calculator calc1 = new Calculator(10,20);
            Calculator calc2 = new Calculator(10, 30);
            Calculator calc3 = new Calculator(10, 10);

            //object created in static fn
            {
                calc3 = calc1 + calc2 ;

                //to show result
                calc1.Print();
            }
        }
    }
}
