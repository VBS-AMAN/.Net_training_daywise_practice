﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_operator_overloading
{
    /*  class Calculator
      {
          //work on only user defined data
    public int number1, number2;

    //constructor
    public Calculator(int num1, int num2)
    {
        number1 = num1;
        number2 = num2;
    }

    // method- function to perform operation - by changing sign of integer
    public static Calculator operator -(Calculator c1)
    {
        c1.number1 = -c1.number1;
        c1.number2 = -c1.number2;
        return c1;
    }
    public void Print()
    {
        Console.WriteLine("Number 1 = " + number1);
        Console.WriteLine("Number 2 = " + number2);
    }




  //work on only user defined data
    public int number1, number2;

    //constructor
    public Calculator(int num1, int num2)
    {
        number1 = num1;
        number2 = num2;
    }

    // method- function to perform operation - by changing sign of integer
    public static Calculator operator +(Calculator c1, Calculator c2)
    {
        c1.number1 = c1.number1 + c2.number1;
        c1.number2 = c1.number2 + c2.number2;
        return c1;
    }
    public void Print()
    {
        Console.WriteLine("Number 1 = " + number1);
        Console.WriteLine("Number 2 = " + number2);
    } 
  }
  }*/
}
