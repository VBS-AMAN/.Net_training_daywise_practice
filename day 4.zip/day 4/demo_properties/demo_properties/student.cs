﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_properties
{
    class student
    {
        public int AdharCardNo
        {
            get { return 1233212343; }//read only property
        }
        public int id { get; set; } // in this implementation private field is automatically declared
        private string FaceBookLink; // private field
        public string name; // private field
        public string Name //defining property
        {
            get { return name; }
            set { name = value; }
        }
    }
}
