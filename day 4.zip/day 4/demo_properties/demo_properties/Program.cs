﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_properties
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("implementing properties");

            student newstudent = new student();

            newstudent.id = 1;
            newstudent.Name = "Aman";
           // newstudent.AdharCardNo = "234";

            // string interpolation to view output
            Console.WriteLine($"student id: {  newstudent.id} & student name is:{  newstudent.Name} , card no is:{  newstudent.AdharCardNo} ");
        }
    }
}
