﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_inheritance
{
    internal class Program
    {
        static void Main(string[] args)
        {
            newChild child1 = new newChild();
            child1.read("Akshay", "Martial Arts");
            
        }
    }
}
