﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_inheritance
{
    class baseclass
    {
        public string name;
        public string subject;


        /// method
        public void read(string name, string subject)
        {
            this.name = name;
            this.subject = subject;
            Console.WriteLine($"i am {name} and subject {subject}");

        }

        class Child:baseclass

        {
            public Child ()
            {
                Console.WriteLine("this is my child class..!!");
            }
        }
    }
}
