﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_MULTIPLE_inheritance
{
    internal interface IBasicCalculator
    {
        int add(int a, int b);
        int subtract(int a, int b);

    }
    interface IScientificCalc
    {
        float add(float a, float b);
        float subtract(float a, float b);
    }

    class Calculation : IBasicCalculator, IScientificCalc
    {
        public int add(int a, int b)
        {
            // throw new NotImplementedException();
            Console.WriteLine(" This a Add() coming from IBasicCalculator Class ");
            return a + b;
        }

        public float add(float a, float b)
        {
            //throw new NotImplementedException();
            Console.WriteLine(" This a Add() coming from IScientificCalc Class ");
            return a + b;

        }

        public int subtract(int a, int b)
        {
            // throw new NotImplementedException();
            Console.WriteLine("This is a Subtract() coming from IBasicCalculator Class");
            return b - a;
        }

        public float subtract(float a, float b)
        {
            // throw new NotImplementedException();
            Console.WriteLine(" This a subtract() coming from IScientificCalc Class ");
            return b - a;
        }
    }
}