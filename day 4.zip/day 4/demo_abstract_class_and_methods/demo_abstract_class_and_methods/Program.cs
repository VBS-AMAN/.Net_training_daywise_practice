﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_abstract_class_and_methods
{
    class Program
    {
       /* static void Main(string[] args)
        {
            Console.WriteLine("Absract Class and Methods");

            //Animal obj1 = new Animal();//Can't create An Object of Abstract class
            //Creating object of the dog class 
            Dog mydog = new Dog();
            mydog.No_of_Kids = 0;
            //mydog.Weight();
            // mydog.Age();
            Console.WriteLine(mydog.Colortype());

            Console.WriteLine("MyDog has" + mydog.No_of_Kids);
            //IDomesticAnimal mydogAnimal = new IDomesticAnimal();//Can't create an object 

            IDomesticAnimal myFirstPet = mydog; // We are allwod to create ref to
                                                // an already exiting object of the class 
            myFirstPet.No_of_Kids = 1;
            Console.WriteLine("MyFirstpet" + myFirstPet.No_of_Kids);

            Console.WriteLine("MyDog has" + mydog.No_of_Kids);

            Console.WriteLine("-----------------------For First Pet---------------------");
            Console.WriteLine(myFirstPet.Colortype());*/


        }
    }
}
