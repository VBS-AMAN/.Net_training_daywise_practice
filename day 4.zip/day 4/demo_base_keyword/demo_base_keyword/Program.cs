﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_base_keyword
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Dog ginger = new Dog();
            ginger.showcolor();

            ginger.Speak();// We are refering child class speak()

        }
    }
}
