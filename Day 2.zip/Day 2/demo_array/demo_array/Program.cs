﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_array
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("working with array");
            string[] mobilePhones = { "Oneplus", "i phone", "samsung", "redmi" };

            Console.WriteLine(mobilePhones[0]);//display element

            mobilePhones[1] = "Blackberry";// change element
            Console.WriteLine(mobilePhones[1]);

            //for display all element of array using for loop

            for (int i= 0; i< mobilePhones.Length; i++)
            {
                Console.WriteLine(mobilePhones[i]);


            }

            Console.WriteLine(mobilePhones.Length);
            //Console.WriteLine(mobilePhones);

            // displaying elements using Foreach loop
            foreach (var item in mobilePhones)
            {
                Console.WriteLine(item);

            }
            //sorting of an array
            Console.WriteLine("----------sorting an array--------");

            Array.Sort(mobilePhones);
            foreach (var item in mobilePhones)
            {
                Console.WriteLine(item);
            }
        }
    }
}
