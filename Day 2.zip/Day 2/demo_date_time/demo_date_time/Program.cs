﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_date_time
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with date and time in c#");
            DateTime todayDate = new DateTime(2022,09,01,10,20,45);
            Console.WriteLine(todayDate.Date.Year);
            Console.WriteLine(todayDate.Date.Month);
            Console.WriteLine(todayDate.Date.Day);

            Console.WriteLine("-------------------display time details------------");

            Console.WriteLine(todayDate.Hour);
            Console.WriteLine(todayDate.Minute);
            Console.WriteLine(todayDate.Second);

            Console.WriteLine(todayDate.DayOfWeek);
            Console.WriteLine(todayDate.ToString(" MMMM dddd, yyyy"));
           

            Console.WriteLine(DateTime.Now);
            Console.WriteLine(DateTime.MinValue);
            Console.WriteLine(DateTime.MaxValue);



        {

        }
        }
    }
}
