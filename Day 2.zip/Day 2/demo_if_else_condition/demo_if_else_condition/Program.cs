﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_if_else_condition
{
    class Program
    {
        static void Main(string[] args)
       {
             Console.WriteLine("working with if else condition");
             Console.WriteLine("enter your age");

             int age = Convert.ToInt32(Console.ReadLine());

             if (age >= 18)
             {
                 Console.WriteLine(" eligible for votiong in bhrat");
             }
             else
             {
                 Console.WriteLine(" ghr jaoo waps...!!");


             }
         }
     }
 }



        



