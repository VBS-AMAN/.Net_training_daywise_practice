﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace DEMO_culture_info
{
    class Program
    {
       

            static void Main(string[] args)
            {
                Console.WriteLine("Working with Culture Information ");
                CultureInfo culture = new CultureInfo("en");

                Console.WriteLine(culture.Name);
                string currentCulture = Thread.CurrentThread.CurrentCulture.DisplayName;
                DateTime currentTime = DateTime.Now;
                string dateinUSA = currentTime.ToString("D",new CultureInfo("en-US"));
                Console.WriteLine(dateinUSA);
                string dateinHindi  = currentTime.ToString("d",new CultureInfo("hi-IN"));
                Console.WriteLine(dateinHindi);
                string dateinJapan = currentTime.ToString("d", new CultureInfo("ja-JP"));
                Console.WriteLine(dateinJapan);
                string dateinFrench = currentTime.ToString("D", new CultureInfo("fr-FR"));
                Console.WriteLine(dateinFrench);

                CultureInfo currentculture = Thread.CurrentThread.CurrentCulture;
                Calendar cl = currentculture.Calendar;


                Calendar mycalender = new HijriCalendar();
                DateTime dt = new DateTime(2022, 01, 09, mycalender);
                Console.WriteLine("HijriCalander Year : " + dt.Year);
                Console.WriteLine("HijriCalender Month: " + dt.Month);
                Console.WriteLine("HijriCalender Total Date:" + dt.ToString("D"));




            }
        }
    }







}
    }
}
