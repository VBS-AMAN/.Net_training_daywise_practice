﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_user_defined_exception
{
   public class temIsZeroException : Exception /// inheriting exception materialto user defined exception
    {
        public temIsZeroException (string message) : base (message) //the value of this message argument come frombase calss(public class temIsZeroException : Exception)
        {
            

        }
    }
    class Temprature
    {
        int temperature = 0;
        //method
        public void showTemp()
        {
            if (temperature == 0)
            {
                throw (new temIsZeroException("zero temp find"));

            }
            else
            {
                Console.WriteLine("Temperature : {0}", temperature);
            }
        }
    } 
}


