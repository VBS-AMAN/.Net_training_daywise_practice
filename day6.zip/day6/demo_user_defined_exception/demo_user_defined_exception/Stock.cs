﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_user_defined_exception
{
    public class OutofStock : Exception
    {
        public OutofStock(string message) : base(message) //the value of this message argument come frombase calss(public class temIsZeroException : Exception)
        {


        }
    }
    class Stock
    {
        int stock = Convert.ToInt32(Console.ReadLine());
        //method
        public void Stockcheck()
        {
            if (stock > 5)
            {
                throw (new OutofStock("not sufficient stock"));

            }
            else
            {
                Console.WriteLine("stock : {0}", stock);
            }
        }
    }

}
