﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_user_defined_exception
{
    class Program
    {
        static void Main(string[] args)
        {
            /*  Console.WriteLine("user defined exception");
              Temprature temp = new Temprature();

              try
              {
                  temp.showTemp();
              }
                catch (temIsZeroException ex)
              {
                  Console.WriteLine("Temprature is Zero Exception :{0}", ex.Message);
                 // throw;
              }*/

            Console.WriteLine("enter no of stock:");
           Stock stock1 = new Stock();

            try
            {
                stock1.Stockcheck();
            }
            catch (OutofStock ex)
            {
                Console.WriteLine("stock Exception :{0}", ex.Message);
                // throw;
            }
            




        }
    }
}
