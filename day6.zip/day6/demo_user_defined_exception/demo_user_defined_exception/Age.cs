﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_user_defined_exception
{
    public class AgeIsLess : Exception
    {
        public AgeIsLess(string message) : base(message) //the value of this message argument come frombase calss(public class temIsZeroException : Exception)
        {


        }
    }
    class Age
    {
        int age = Convert.ToInt32(Console.ReadLine());
        //method
        public void Agecheck()
        {
            if (age < 20)
            {
                throw (new AgeIsLess(" bde hokr aao"));

            }
            else
            {
                Console.WriteLine("Age : {0}", age);
            }
        }
    }


}
