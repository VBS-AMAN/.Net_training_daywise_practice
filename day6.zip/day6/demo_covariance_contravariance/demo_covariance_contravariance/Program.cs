﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_covariance_contravariance
{
    class Program
    {
        static string GetString()
        {
            return "sample text";
        }
        static void Main(string[] args)
        {
            Console.WriteLine("covariance and contravariance");

            Console.WriteLine("Array data type supports variant");
            //means
            Object[] objArray = new string[10];
            //here we are assigning a string array to an object array variable

            ///covariance is not type safe means
            objArray[0] = "12";// 12;
            Console.WriteLine(objArray[0]);

            Console.WriteLine("Delegates covariance");
            //means
            Func<object> delegateobj = GetString;
          //  string strobj = delegateobj.ToString();
           // Console.WriteLine(strobj);

        }
    }
}
