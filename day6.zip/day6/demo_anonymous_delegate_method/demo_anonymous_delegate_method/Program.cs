﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Anonymous_DelegateMethod
{
    public delegate void Mydelegate();
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Mydelegate del1 = delegate () //Not a function  //anonymous function
            {
                Console.WriteLine("Anonymous Delegate Method !!");
            };
            del1();
        }
    }
}