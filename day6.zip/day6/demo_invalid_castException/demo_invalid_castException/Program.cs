﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_invalid_castException
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Invalid cast exception");
            int i = 123;
            string s = "i am feeling good";
            object obj = s; // object consist string

            try
            {
                i = (int)obj;
                Console.WriteLine("this writeline is the end of try block ");

            }

            catch (Exception ex)
            {

                Console.WriteLine("catching the {0} exception trigger the finaally block ", ex.GetType());

               // throw;
            }

            finally
            {
                Console.WriteLine("executing the finally block..!!");
                Console.WriteLine("i ={0}", i);
            }
            
            
        }
    }
}
