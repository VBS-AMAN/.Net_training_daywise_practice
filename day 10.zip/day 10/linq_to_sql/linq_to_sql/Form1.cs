﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data.Linq.SqlClient;

namespace linq_to_sql
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connection = "Data Source=192.168.1.230;Initial Catalog=AdventureWorks2017;Persist Security Info=True;User ID=trainee2022;Password=trainee@2022";
            DataContext db = new DataContext(connection);
            Table<Contact> contacts = db.GetTable<Contact>();
            //retreiving data from database
            var query = from c in contacts
                        where c.Title == "Mr."
                        orderby c.FirstName
                        select c;
            foreach (var item in query)
            {
                richTextBox1.AppendText(item.Title + item.FirstName + item.LastName);
            }
        }
    }

    [Table(Name = "Person.Person")]

    public class Contact

    {

        [Column]

        public string Title;

        [Column]

        public string FirstName;

        [Column]

        public string LastName;


    }
}
