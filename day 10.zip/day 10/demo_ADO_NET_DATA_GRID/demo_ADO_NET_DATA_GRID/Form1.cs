﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace demo_ADO_NET_DATA_GRID
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ConnString = "Data Source=192.168.1.230;Initial Catalog=Freshers_Training2022;Persist Security Info=True;User ID=trainee2022;Password=trainee@2022";
            SqlConnection connection = new SqlConnection(ConnString);
            connection.Open();
            string querystring = "Select * from Amang_employee111 ";
            SqlDataAdapter adapter = new SqlDataAdapter(querystring, connection);
            DataTable d1 = new DataTable("emp detail");
            adapter.Fill(d1);
            dataGridView1.DataSource = d1;
            dataGridView2.DataSource = d1;
            connection.Dispose();
            connection.Close();
        }
    }
}
