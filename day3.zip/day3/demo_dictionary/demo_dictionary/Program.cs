﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Dictionary Implementation ");

            Dictionary<string, string> EmpList = new Dictionary<string, string>();

            EmpList.Add("Aman", "Programmer");
            EmpList.Add("Avinash", "Architect");
            EmpList.Add("Kartik", "Manager");

            foreach (KeyValuePair<string, string> item in EmpList)
            {
                Console.WriteLine($"Name:{item.Key} and Dept: {item.Value}");
            }

            Console.WriteLine("Displaying only values from Dictionary");
            foreach (var item in EmpList.Values)
            {
                Console.WriteLine("value from the list :" + item);
            }


        }
    }
}
