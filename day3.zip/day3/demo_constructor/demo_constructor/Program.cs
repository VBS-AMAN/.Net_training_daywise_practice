﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("constructor implementation");

            Employee emp1 = new Employee();
            Console.WriteLine(emp1.dept);

            Employee emp2 = new Employee();
            Console.WriteLine(emp2.dept);



        }
    }
}
