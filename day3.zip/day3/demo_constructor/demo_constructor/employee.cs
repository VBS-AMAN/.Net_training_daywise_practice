﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_constructor
{
    class Employee
    {
        public string name;
        public string dept;

        public Employee() //DEFAULT CONSTRUCTOR
        {
            dept = "training & development";

        }
            public Employee(string name, string dept)
        {
            this.name = name;
            this.dept = dept;

        
        }

    }
}
