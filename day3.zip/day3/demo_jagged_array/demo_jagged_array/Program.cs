﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_jagged_array
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("jagged array ");
            int[][] myarr = new int[3][];
            myarr[0] = new int[4] { 11, 21, 31, 41 };
            myarr[1] = new int[6] { 11, 12, 21, 31, 41, 61 };
            myarr[2] = new int[] { 11, 12, 21, 31, 41, 61,81,91,87 };

            /* foreach (var item in myarr)
             {
                 Console.WriteLine();

                 foreach (var item1 in myarr)
                 {
                     Console.WriteLine(item1+" ");
                 }

             }*/
            // using nested foreach loop
            string display = string.Empty;
            foreach (int[] row in myarr)
            {
                foreach (int column in row)
                {
                    display += column + " ";
                }
                // move to the next line
                display += "\n";
            }
            Console.WriteLine(display);


        }
    }
}
