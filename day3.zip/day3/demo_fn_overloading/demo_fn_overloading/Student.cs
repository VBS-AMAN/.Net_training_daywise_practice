﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_fn_overloading
{
    internal class Student
    {
        public void StudentMesssage()
        {
            Console.WriteLine(" I am A Message coming from student class....!!!!");
        }
    }
}