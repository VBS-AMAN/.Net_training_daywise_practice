﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_access_modifires
{
   /* class NewProgram
    {
        public void GetPublic() { }
        private void GetPrivate() { }//Not acessible out side the class 
        internal void GetInternal() { }
        protected void GetProtected() { }
        protected internal void GetProtectedInternal() { }
        protected private void GetPrivateProtected() { }
    }
    internal class Program : NewProgram

    {
        public void show()
        {
            MyClass obj2 = new MyClass();
            GetProtected();//We can access it directly after inheritance without any object of any class  
            GetPrivateProtected();
            GetInternal();//They can accessed within the assembly 
            GetProtectedInternal(); //They can be used inside derived classes(same and /or in different assembly)
                                    //or by creating object or the base class in different assembly

        }

        static void Main(string[] args)
        {
            NewProgram obj1 = new NewProgram();
            obj1.GetInternal();//They can accessed within the assembly 
            obj1.GetProtectedInternal();
            obj1.GetPublic();
            //obj1.Get 



        }
    } */
}
