﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator_App
{
    public partial class Form1 : Form
    {
        public string firstoperand = "";
        public string secondoperand = "";

        public string operate = "";



        public Form1()
        {
            InitializeComponent();
        }

        private void Btn7_Click(object sender, EventArgs e)
        {
            firstoperand += Btn7.Text;
            textBox_Res.Text = firstoperand;
        }

       

        private void btn8_Click(object sender, EventArgs e)
        {
            firstoperand += btn8.Text;
            textBox_Res.Text =firstoperand;
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            firstoperand += btn9.Text;
            textBox_Res.Text = firstoperand;
        }

        private void btn_div_Click(object sender, EventArgs e)
        {
            operate = btn_div.Text.ToString();
            secondoperand = firstoperand;
            firstoperand = "";
            textBox_Res.Text = operate;
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            firstoperand += btn4.Text;
            textBox_Res.Text = firstoperand;
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            firstoperand += btn5.Text;
            textBox_Res.Text = firstoperand;
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            firstoperand += btn6.Text;
            textBox_Res.Text = firstoperand;
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            firstoperand += btn1.Text;
            textBox_Res.Text = firstoperand;
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            firstoperand += btn2.Text;
            textBox_Res.Text = firstoperand;
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            firstoperand += btn3.Text;
            textBox_Res.Text = firstoperand;
        }

        private void btn_zero_Click(object sender, EventArgs e)
        {
            firstoperand += btn_zero.Text;
            textBox_Res.Text = firstoperand;
        }

        private void btn_point_Click(object sender, EventArgs e)
        {
            firstoperand += btn_point.Text;
            textBox_Res.Text = firstoperand;
        }

        private void btn_plus_Click(object sender, EventArgs e)
        {
            operate = btn_plus.Text.ToString();
            secondoperand = firstoperand;
            firstoperand = "";
            textBox_Res.Text = operate;
        }

        public string result;
        private void btn_equal_Click(object sender, EventArgs e)


            
        {

            if (operate.Equals("+") )
            {
                result = ( Convert.ToDecimal(firstoperand) + Convert.ToDecimal(secondoperand)).ToString();
                textBox_Res.Text = result;
            }


            if (operate.Equals("-"))
            {
                result = (Convert.ToDecimal(firstoperand) - Convert.ToDecimal(secondoperand)).ToString();
                textBox_Res.Text = result;
            }

            if (operate.Equals("/"))
            {
                result = (Convert.ToDecimal(secondoperand) / Convert.ToDecimal(firstoperand)).ToString();
                textBox_Res.Text = result;
            }

            if (operate.Equals("*"))
            {
                result = (Convert.ToDecimal(firstoperand) *Convert.ToDecimal(secondoperand)).ToString();
                textBox_Res.Text = result;
            }


           





        }

        private void btn_clr_Click(object sender, EventArgs e)
        {
            textBox_Res.Text = "";
            firstoperand = "";
            secondoperand = "";

        }

        private void btn_mul_Click(object sender, EventArgs e)
        {
            operate = btn_mul.Text.ToString();
            secondoperand = firstoperand;
            firstoperand = "";
            textBox_Res.Text = operate;
        }

        private void btn_minus_Click(object sender, EventArgs e)
        {
            
            operate = btn_minus.Text.ToString();
            secondoperand = firstoperand;
            firstoperand = "";
            textBox_Res.Text = operate;
        }
    }
}
