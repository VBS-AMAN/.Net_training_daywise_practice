﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
namespace _1st_project_stopwatch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Stopwatch sw;
        private void Form1_Load(object sender, EventArgs e)
        {
            sw = new Stopwatch();


        }

        private void start_btn1_Click(object sender, EventArgs e)
        {
            sw.Start();
         
        }

      
        private void timer1_Tick(object sender, EventArgs e)
        {

            lab_H.Text = string.Format("{0:hh\\:mm\\:ss\\.ff}", sw.Elapsed); 
        }

        private void lab_H_Click(object sender, EventArgs e)
        {

        }

        private void lab_M_Click(object sender, EventArgs e)
        {

        }

        private void Lab_S_Click(object sender, EventArgs e)
        {
        }

        private void stopbtn2_Click(object sender, EventArgs e)
        {
            sw.Stop();
        }

        private void Reset_BTN3_Click(object sender, EventArgs e)
        {
           // lab_H.Text = "00:00:00.00";
            sw.Restart();
        }
    }
}
