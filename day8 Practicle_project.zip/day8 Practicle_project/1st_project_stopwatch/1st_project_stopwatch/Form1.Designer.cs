﻿
namespace _1st_project_stopwatch
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lab_H = new System.Windows.Forms.Label();
            this.start_btn1 = new System.Windows.Forms.Button();
            this.stopbtn2 = new System.Windows.Forms.Button();
            this.Reset_BTN3 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // lab_H
            // 
            this.lab_H.AutoSize = true;
            this.lab_H.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_H.Location = new System.Drawing.Point(261, 114);
            this.lab_H.Name = "lab_H";
            this.lab_H.Size = new System.Drawing.Size(137, 25);
            this.lab_H.TabIndex = 0;
            this.lab_H.Text = "00:00:00.00";
            this.lab_H.Click += new System.EventHandler(this.lab_H_Click);
            // 
            // start_btn1
            // 
            this.start_btn1.Location = new System.Drawing.Point(236, 188);
            this.start_btn1.Name = "start_btn1";
            this.start_btn1.Size = new System.Drawing.Size(75, 23);
            this.start_btn1.TabIndex = 1;
            this.start_btn1.Text = "START";
            this.start_btn1.UseVisualStyleBackColor = true;
            this.start_btn1.Click += new System.EventHandler(this.start_btn1_Click);
            // 
            // stopbtn2
            // 
            this.stopbtn2.Location = new System.Drawing.Point(317, 188);
            this.stopbtn2.Name = "stopbtn2";
            this.stopbtn2.Size = new System.Drawing.Size(75, 23);
            this.stopbtn2.TabIndex = 2;
            this.stopbtn2.Text = "STOP";
            this.stopbtn2.UseVisualStyleBackColor = true;
            this.stopbtn2.Click += new System.EventHandler(this.stopbtn2_Click);
            // 
            // Reset_BTN3
            // 
            this.Reset_BTN3.Location = new System.Drawing.Point(398, 188);
            this.Reset_BTN3.Name = "Reset_BTN3";
            this.Reset_BTN3.Size = new System.Drawing.Size(75, 23);
            this.Reset_BTN3.TabIndex = 5;
            this.Reset_BTN3.Text = "RESET";
            this.Reset_BTN3.UseVisualStyleBackColor = true;
            this.Reset_BTN3.Click += new System.EventHandler(this.Reset_BTN3_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Reset_BTN3);
            this.Controls.Add(this.stopbtn2);
            this.Controls.Add(this.start_btn1);
            this.Controls.Add(this.lab_H);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lab_H;
        private System.Windows.Forms.Button start_btn1;
        private System.Windows.Forms.Button stopbtn2;
        private System.Windows.Forms.Button Reset_BTN3;
        private System.Windows.Forms.Timer timer1;
    }
}

